package com.estudosMS.hroauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrOauthApplicationTests {

	@Test
	void contextLoads() {
	}

}
