package com.estudosMs.hrworker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrWorkerApplicationTests {

	@Test
	void contextLoads() {
	}

}
