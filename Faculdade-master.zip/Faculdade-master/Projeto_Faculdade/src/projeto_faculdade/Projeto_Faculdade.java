
package projeto_faculdade;

import projeto_faculdade.DAO.DAOAluno;
import projeto_faculdade.Exception.BusinessException;
import projeto_faculdade.Fachada.Fachada;
import projeto_faculdade.Model.Aluno;

import projeto_faculdade.View.TelaCadastroLogin;
import projeto_faculdade.View.Tela_Login;


public class Projeto_Faculdade {

    
    public static void main(String[] args) {
        
        
        
        Tela_Login tela_Login = new Tela_Login();
        tela_Login.setVisible(true);
        //Aluno a = new Aluno("Sávio Arthur", "100");
        
        
	//Semestre s = new Semestre();
		
        //Fachada.getInstance().salvarEditarAluno(a);
       
        
       // Fachada.getInstance().salvarEditarSemestre(s);
                
    }
    
}
