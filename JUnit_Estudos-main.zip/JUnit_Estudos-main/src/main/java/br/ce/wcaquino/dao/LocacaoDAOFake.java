package br.ce.wcaquino.dao;

import java.util.List;

import br.ce.wcaquino.entidades.Locacao;

public class LocacaoDAOFake implements LocacaoDAO {

	public void salvar(Locacao locacao) {
		// TODO Auto-generated method stub

	}

	public List<Locacao> obterLocacoesPendentes() {
		// TODO Auto-generated method stub
		return null;
	}

}
