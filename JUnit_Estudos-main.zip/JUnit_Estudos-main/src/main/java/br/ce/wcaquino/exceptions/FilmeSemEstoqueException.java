package br.ce.wcaquino.exceptions;

public class FilmeSemEstoqueException extends Exception {
	
	private static final long serialVersionUID = -4970527916966267734L;

}
