package com.estudosSB.api.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.estudosSB.api.entities.Mensalidade;


public interface MensalidadeRepository2 extends JpaRepository<Mensalidade, Long>  {

}
