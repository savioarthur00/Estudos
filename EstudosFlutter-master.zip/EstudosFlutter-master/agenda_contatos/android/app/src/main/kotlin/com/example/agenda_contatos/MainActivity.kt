package com.example.agenda_contatos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
