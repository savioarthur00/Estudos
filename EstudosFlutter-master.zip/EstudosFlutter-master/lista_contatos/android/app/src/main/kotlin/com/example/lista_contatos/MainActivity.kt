package com.example.lista_contatos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
