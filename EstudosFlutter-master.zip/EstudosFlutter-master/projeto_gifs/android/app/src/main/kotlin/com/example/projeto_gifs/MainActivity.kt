package com.example.projeto_gifs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
