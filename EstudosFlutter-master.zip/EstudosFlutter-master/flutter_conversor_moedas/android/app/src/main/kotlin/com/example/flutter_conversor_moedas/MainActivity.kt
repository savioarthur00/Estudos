package com.example.flutter_conversor_moedas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
