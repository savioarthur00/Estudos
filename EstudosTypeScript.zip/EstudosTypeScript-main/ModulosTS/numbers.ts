export const n1:number = 10
export const n2:number = 20
export const n3:number = 30