export default function importGreet(){
    console.log("Olá, está função foi exportada!")
}