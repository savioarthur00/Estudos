"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.n3 = exports.n2 = exports.n1 = void 0;
exports.n1 = 10;
exports.n2 = 20;
exports.n3 = 30;
