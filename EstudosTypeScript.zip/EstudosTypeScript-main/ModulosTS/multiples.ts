export const a: number =10
export const b: string ="Olá"

export function myFunction():void{
    console.log("Função importada...")
}