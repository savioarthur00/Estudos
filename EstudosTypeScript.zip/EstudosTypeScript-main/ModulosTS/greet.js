"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function importGreet() {
    console.log("Olá, está função foi exportada!");
}
exports.default = importGreet;
