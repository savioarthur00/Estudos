
export interface Human {
    name:string,
    age:number
}