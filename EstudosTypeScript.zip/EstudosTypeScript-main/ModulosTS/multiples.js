"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.myFunction = exports.b = exports.a = void 0;
exports.a = 10;
exports.b = "Olá";
function myFunction() {
    console.log("Função importada...");
}
exports.myFunction = myFunction;
