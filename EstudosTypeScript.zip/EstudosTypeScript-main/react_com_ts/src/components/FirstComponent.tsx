//Components 

import React, {ReactElement} from "react";

 

function FirstComponent():ReactElement{
    return (
        <div>
            <h1>Meu primeiro componente</h1>
        </div>
    )
}
export default FirstComponent


 
