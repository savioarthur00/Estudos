export interface ITask {
    id: number;
    nome: string,
    formaDePagamento: string
  }