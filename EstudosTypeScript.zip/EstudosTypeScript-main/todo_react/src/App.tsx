import React from 'react';


function App() {
  return (
    <div>

        <header>
            <h1>React + TS Todo</h1>
        </header>

        <h1>Conteudo..</h1>

        <footer>
            <p>
                <span>
                React + TS Todo Footer
                </span> @2023
            </p>
        </footer>

    </div>

  );
}

export default App;
