
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header> <h1> Faça seu login </h1></header>
    <section>
    
    
        <form  method= "post" action="loginResultado.php">
        <label for="login"> Login </label>
         <input type="text" name="login" id="idlogin">
         <label for="senha">Senha </label>
         <input type="text" name="senha" id="idsenha">
         <input type="submit" value="Enviar">

        </form>

    </section>

</body>
</html>


